__version__ = '0.3.0+ecffe24'
git_version = 'ecffe24db5b59101d2301d0e7b11a87189731483'
