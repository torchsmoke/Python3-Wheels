__version__ = '0.4.0a0+8afed30'
git_version = '8afed303af3de41f3586007079c0534543c8f663'
