__version__ = '0.5.0a0+09494ea'
git_version = '09494ea545738538f9db2dceeffe10d421060ee5'
